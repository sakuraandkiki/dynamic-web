import tkinter as tk
from tkinter import messagebox
import sqlite3
import random
import string
def random_id():
    return ''.join(random.choices(string.digits, k=10))
def setup_teacher_table():
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS teacher (
        id TEXT PRIMARY KEY,
        teacher_name TEXT,
        password TEXT
    )''')
    conn.commit()
    conn.close()
def register_teacher():
    teacher_name = name_entry.get()
    password = password_entry.get()

    teacher_id = random_id()

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()

    cursor.execute("INSERT INTO teacher (id, teacher_name, password) VALUES (?, ?, ?)",
                   (teacher_id, teacher_name, password))
    conn.commit()
    conn.close()

    messagebox.showinfo("Success", f"Teacher registered successfully! Your ID is {teacher_id}")
def show_register_teacher():
    for widget in root.winfo_children():
        widget.destroy()

    tk.Label(root, text="Register Teacher").pack()
    tk.Label(root, text="Username").pack()
    global name_entry
    name_entry = tk.Entry(root)
    name_entry.pack()
    tk.Label(root, text="Password").pack()
    global password_entry
    password_entry = tk.Entry(root, show="*")
    password_entry.pack()
    tk.Button(root, text="Register", command=register_teacher).pack()
    tk.Button(root, text="Close", command=root.quit).pack()

setup_teacher_table()
root = tk.Tk()
root.title("Teacher Registration System")
show_register_teacher()
root.mainloop()
