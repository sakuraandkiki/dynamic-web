import tkinter as tk
from tkinter import messagebox
import sqlite3
import random
import string
from tkinter import filedialog
import pandas as pd

def idset():
    user_id = ''.join(random.choices(string.digits, k=10))
    return user_id

root = tk.Tk()
root.title("Quiz Management System")
root.geometry("800x600")

def refresh_window():
    for widget in root.winfo_children():
        widget.destroy()

def show_login_screen():
    refresh_window()
    tk.Label(root, text="Login", font=("Helvetica", 16)).pack(pady=15)
    tk.Label(root, text="Username").pack()
    global login_name_entry
    login_name_entry = tk.Entry(root)
    login_name_entry.pack()
    tk.Label(root, text="Password").pack()
    global login_password_entry
    login_password_entry = tk.Entry(root, show='*')
    login_password_entry.pack()
    tk.Button(root, text="Login as User", command=user_login).pack(pady=15)
    tk.Button(root, text="Login as Teacher", command=teacher_login).pack(pady=15)
    tk.Button(root, text="Register", command=show_register_screen).pack(pady=15)

def show_register_screen():
    refresh_window()
    tk.Label(root, text="Register", font=("Helvetica", 16)).pack(pady=15)
    tk.Label(root, text="Passport").pack()
    global passport_entry
    passport_entry = tk.Entry(root)
    passport_entry.pack()
    tk.Label(root, text="Username").pack()
    global name_entry
    name_entry = tk.Entry(root)
    name_entry.pack()
    tk.Label(root, text="Password").pack()
    global password_entry
    password_entry = tk.Entry(root, show='*')
    password_entry.pack()
    tk.Button(root, text="Register", command=user_register).pack(pady=15)
    tk.Button(root, text="Back to Login", command=show_login_screen).pack(pady=15)

def user_register():
    user_passport = passport_entry.get()
    user_name = name_entry.get()
    password = password_entry.get()
    user_id = idset()
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO id_table (name) VALUES (?)", (user_name,))
    cursor.execute("INSERT INTO user_information (id, user_passport, user_name, password) VALUES (?, ?, ?, ?)",
                   (user_id, user_passport, user_name, password))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", f"User registered successfully! Your ID is {user_id}")

def user_login():
    user_name = login_name_entry.get()
    password = login_password_entry.get()
    conn = sqlite3.connect("quiz.db")
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM user_information WHERE user_name = ? AND password = ?", (user_name, password))
    user = cursor.fetchone()
    if user is not None:
        messagebox.showinfo("Success", "Successfully logged in")
        global current_user_id
        current_user_id = user[0]
        show_user_screen()
    else:
        messagebox.showerror("Error", "Invalid username or password")

def show_user_screen():
    refresh_window()
    tk.Label(root, text="User Menu", font=("Helvetica", 16)).pack(pady=15)
    tk.Button(root, text="Take Quiz", command=take_quiz).pack(pady=15)
    tk.Button(root, text="View Results", command=view_results).pack(pady=15)
    tk.Button(root, text="Logout", command=show_login_screen).pack(pady=15)

def take_quiz():
    refresh_window()
    tk.Label(root, text="Take Quiz", font=("Helvetica", 16)).pack(pady=15)

    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM question")
    questions = cursor.fetchall()
    question_vars = []
    for question in questions:
        question_id, question_text = question
        tk.Label(scrollable_frame, text=question_text).pack(pady=5)
        var = tk.StringVar()
        question_vars.append((question_id, var))
        cursor.execute("SELECT * FROM answer WHERE question_id = ?", (question_id,))
        answers = cursor.fetchall()
        for answer in answers:
            answer_id, question_id, answer1, answer2, answer3, correct_option = answer
            tk.Radiobutton(scrollable_frame, text=answer1, variable=var, value=answer1).pack(pady=2)
            tk.Radiobutton(scrollable_frame, text=answer2, variable=var, value=answer2).pack(pady=2)
            tk.Radiobutton(scrollable_frame, text=answer3, variable=var, value=answer3).pack(pady=2)

    def answers_submit():
        for question_id, var in question_vars:
            user_answer = var.get()
            cursor.execute("INSERT INTO useranswer (user_id, question_id, user_answer) VALUES (?, ?, ?)",
                           (current_user_id, question_id, user_answer))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Successfully submitted")
        show_user_screen()

    tk.Button(scrollable_frame, text="Submit", command=answers_submit).pack(pady=15)

def view_results():
    refresh_window()
    tk.Label(root, text="Your Results", font=("Helvetica", 16)).pack(pady=15)

    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT question.question_text, useranswer.user_answer, answer.correct_option
                      FROM useranswer
                      JOIN question ON useranswer.question_id = question.id
                      JOIN answer ON useranswer.question_id = answer.question_id
                      WHERE useranswer.user_id = ?""", (current_user_id,))
    results = cursor.fetchall()
    for result in results:
        question_text, user_answer, correct_answer = result
        tk.Label(scrollable_frame, text=f"Q: {question_text}\nYour answer: {user_answer}\nCorrect answer: {correct_answer}").pack(pady=5)
    tk.Button(scrollable_frame, text="Back to Menu", command=show_user_screen).pack(pady=15)

def teacher_login():
    teacher_name = login_name_entry.get()
    password = login_password_entry.get()
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM teacher WHERE teacher_name = ? AND password = ?", (teacher_name, password))
    teacher = cursor.fetchone()
    if teacher is not None:
        global current_teacher_id
        current_teacher_id = teacher[0]
        messagebox.showinfo("Success", "Successfully logged in")
        show_teacher_screen()
    else:
        messagebox.showerror("Error", "Invalid name or password")

def show_teacher_screen():
    refresh_window()
    tk.Label(root, text="Teacher Menu", font=("Helvetica", 16)).pack(pady=15)
    tk.Button(root, text="View ID Table", command=view_id_table).pack(pady=15)
    tk.Button(root, text="Edit Questions", command=edit_questions).pack(pady=15)
    tk.Button(root, text="Import Exam", command=import_exam).pack(pady=15)
    tk.Button(root, text="Logout", command=show_login_screen).pack(pady=15)
    tk.Button(root, text="Close", command=root.quit).pack(pady=15)

def view_id_table():
    refresh_window()
    tk.Label(root, text="ID Table", font=("Helvetica", 16)).pack(pady=15)

    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM id_table")
    ids = cursor.fetchall()
    for id_record in ids:
        id, name = id_record
        tk.Label(scrollable_frame, text=f"ID: {id}, Name: {name}").pack(pady=5)
        tk.Button(scrollable_frame, text="View Result", command=lambda id=id: view_user_results(id)).pack(pady=5)
    tk.Button(scrollable_frame, text="Back to Menu", command=show_teacher_screen).pack(pady=15)

def view_user_results(user_id):
    refresh_window()
    tk.Label(root, text="User Results", font=("Helvetica", 16)).pack(pady=15)

    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("""SELECT question.question_text, useranswer.user_answer, answer.correct_option
                      FROM useranswer
                      JOIN question ON useranswer.question_id = question.id
                      JOIN answer ON useranswer.question_id = answer.question_id
                      WHERE useranswer.user_id = ?""", (user_id,))
    results = cursor.fetchall()
    score = 0
    total_questions = len(results)
    for result in results:
        question_text, user_answer, correct_answer = result
        tk.Label(scrollable_frame, text=f"Q: {question_text}\nYour answer: {user_answer}\nCorrect answer: {correct_answer}").pack(pady=5)
        if user_answer == correct_answer:
            score += 1
    tk.Label(scrollable_frame, text=f"Total Score: {score} / {total_questions}", font=("Helvetica", 16)).pack(pady=15)
    tk.Button(scrollable_frame, text="Back to teacher screen", command=show_teacher_screen).pack(pady=15)

def import_exam():
    file_path = filedialog.askopenfilename(filetypes=[("Excel files", "*.xlsx *.xls")])
    if not file_path:
        return
    try:
        df = pd.read_excel(file_path)
    except Exception as e:
        messagebox.showerror("Error", f"Failed to read Excel file: {e}")
        return
    required_columns = ["question_text", "answer1", "answer2", "answer3", "correct_option"]
    if not all(column in df.columns for column in required_columns):
        messagebox.showerror("Error", f"Excel file must contain the following columns: {', '.join(required_columns)}")
        return

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()

    for index, row in df.iterrows():
        question_text = row["question_text"]
        answer1 = row["answer1"]
        answer2 = row["answer2"]
        answer3 = row["answer3"]
        correct_option = row["correct_option"]
        cursor.execute("INSERT INTO question (question_text) VALUES (?)", (question_text,))
        question_id = cursor.lastrowid
        cursor.execute("INSERT INTO answer (question_id, answer1, answer2, answer3, correct_option) VALUES (?, ?, ?, ?, ?)",
                       (question_id, answer1, answer2, answer3, correct_option))
    conn.commit()
    conn.close()
    messagebox.showinfo("Success", "Exam imported successfully!")

def edit_questions():
    refresh_window()
    tk.Label(root, text="Edit Questions", font=("Helvetica", 16)).pack(pady=15)

    canvas = tk.Canvas(root)
    scrollbar = tk.Scrollbar(root, orient="vertical", command=canvas.yview)
    scrollable_frame = tk.Frame(canvas)

    scrollable_frame.bind(
        "<Configure>",
        lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")
        )
    )

    canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
    canvas.configure(yscrollcommand=scrollbar.set)

    canvas.pack(side="left", fill="both", expand=True)
    scrollbar.pack(side="right", fill="y")

    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM question")
    questions = cursor.fetchall()

    def add_question():
        refresh_window()
        tk.Label(root, text="Add Question", font=("Helvetica", 16)).pack(pady=15)
        tk.Label(root, text="Question Text").pack()
        question_text_entry = tk.Entry(root)
        question_text_entry.pack()
        tk.Label(root, text="Answer 1").pack()
        answer1_entry = tk.Entry(root)
        answer1_entry.pack()
        tk.Label(root, text="Answer 2").pack()
        answer2_entry = tk.Entry(root)
        answer2_entry.pack()
        tk.Label(root, text="Answer 3").pack()
        answer3_entry = tk.Entry(root)
        answer3_entry.pack()
        tk.Label(root, text="Correct Option (a/b/c)").pack()
        correct_option_entry = tk.Entry(root)
        correct_option_entry.pack()

        def save_question():
            question_text = question_text_entry.get()
            answer1 = answer1_entry.get()
            answer2 = answer2_entry.get()
            answer3 = answer3_entry.get()
            correct_option = correct_option_entry.get()
            conn = sqlite3.connect('quiz.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO question (question_text) VALUES (?)", (question_text,))
            question_id = cursor.lastrowid
            cursor.execute("INSERT INTO answer (question_id, answer1, answer2, answer3, correct_option) VALUES (?, ?, ?, ?, ?)",
                           (question_id, answer1, answer2, answer3, correct_option))
            conn.commit()
            conn.close()
            messagebox.showinfo("Success", "Question added successfully!")
            edit_questions()

        tk.Button(root, text="Save", command=save_question).pack(pady=15)
        tk.Button(root, text="Back to Menu", command=show_teacher_screen).pack(pady=15)

    def delete_question(question_id):
        conn = sqlite3.connect('quiz.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM question WHERE id = ?", (question_id,))
        cursor.execute("DELETE FROM answer WHERE question_id = ?", (question_id,))
        conn.commit()
        conn.close()
        messagebox.showinfo("Success", "Question deleted successfully!")
        edit_questions()

    for question in questions:
        question_id, question_text = question
        tk.Label(scrollable_frame, text=question_text).pack(pady=5)
        tk.Button(scrollable_frame, text="Delete", command=lambda q_id=question_id: delete_question(q_id)).pack(pady=5)

    tk.Button(scrollable_frame, text="Add Question", command=add_question).pack(pady=15)
    tk.Button(scrollable_frame, text="Back to Menu", command=show_teacher_screen).pack(pady=15)

show_login_screen()
root.mainloop()
