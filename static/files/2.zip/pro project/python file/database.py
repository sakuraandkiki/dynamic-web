import sqlite3
def setup_database():
    conn = sqlite3.connect('quiz.db')
    cursor = conn.cursor()

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS id_table (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS teacher (
        id TEXT PRIMARY KEY,
        teacher_name TEXT,
        password TEXT
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS user_information (
        id TEXT PRIMARY KEY,
        user_passport TEXT,
        user_name TEXT,
        password TEXT
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS question (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_text TEXT
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS answer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER,
        answer1 TEXT,
        answer2 TEXT,
        answer3 TEXT,
        correct_option TEXT,
        FOREIGN KEY (question_id) REFERENCES question(id)
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS useranswer (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT,
        question_id INTEGER,
        user_answer TEXT,
        FOREIGN KEY (user_id) REFERENCES user_information(id),
        FOREIGN KEY (question_id) REFERENCES question(id)
    )''')

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS result (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_answer TEXT,
        answer TEXT
    )''')

    conn.commit()
    conn.close()

if __name__ == '__main__':
    setup_database()
    print("Database setup complete.")
